﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2_Advanced_C_

{
    
    public class CustomEventArgs : EventArgs
    {
        public string Message { get; set; }
    }

  
    public delegate void CustomEventHandler(object sender, CustomEventArgs e);

 
    public class EventPublisher
    {
        public event CustomEventHandler MyEvent;

        
        protected virtual void OnMyEvent(CustomEventArgs e)
        {
            MyEvent?.Invoke(this, e);
        }

        public void RaiseEvent()
        {
            OnMyEvent(new CustomEventArgs { Message = "Hello from Event Publisher!" });
        }
    }

   
    public class EventSubscriber
    {
        public EventSubscriber(EventPublisher pub)
        {
            pub.MyEvent += OnMyEvent;
        }

        private void OnMyEvent(object sender, CustomEventArgs e)
        {
            Console.WriteLine($"{e.Message} Received by Event Subscriber");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            EventPublisher pub = new EventPublisher();
            EventSubscriber sub = new EventSubscriber(pub);

            pub.RaiseEvent();
        }
    }
}