﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Test2_Advanced_C_ {
public class GenericClass<T> where T : IComparable<T>
{
    private List<T> _privateCollection = new List<T>();

    public void AddItem(T item)
    {
        _privateCollection.Add(item);
    }

    public T GetItem(int index)
    {
        if (index < 0 || index >= _privateCollection.Count)
        {
            throw new ArgumentOutOfRangeException(nameof(index));
        }

        return _privateCollection[index];
    }

    public List<T> GetSortedDescendingCollection()
    {
        return _privateCollection.OrderByDescending(x => x).ToList();
    }

    public T GetMinimumItem()
    {
        return _privateCollection.Min();
    }

    public T GetMaximumItem()
    {
        return _privateCollection.Max();
    }
    }
}